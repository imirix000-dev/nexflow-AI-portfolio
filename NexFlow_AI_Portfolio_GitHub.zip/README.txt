NEXFLOW AI PORTFOLIO — GitHub Pages

1. Sign in at https://github.com/
2. Create a new public repository named: nexflow-ai-portfolio
3. Upload index.html from this folder (Add file > Upload files).
4. Commit the upload.
5. Open repository Settings > Pages.
6. Under Build and deployment choose Deploy from a branch.
7. Choose Branch: main and Folder: /(root), then Save.
8. Wait for GitHub Pages to publish. Your site URL will be shown in Settings > Pages.

Edit index.html any time to update your portfolio.
The project cards are clearly labeled as demo concepts; replace them with real screenshots/workflows as you build them.
